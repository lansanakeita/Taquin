package src;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Taquin extends AbstractModelEcoutable{
	
	/**
	 * ATTRIBUT DE LA CLASSE
	 */
		private int dimension;
		private Case grille[][];
		private int[][] grid;
		public int compteur = 0; 

		/**
		 * CONSTRUCTEUR DE LA CLASSE
		 * @param dimension : REPRESENTE LA LONGUEUR ET LA LARGEUR DE LA GRILLE
		 */
		public Taquin(int dimension) {
			this.dimension = dimension;
			this.initGrille(dimension);
		}
		
		/**
		 * RENVOIE LA POSITION D'UNE CASE DANS LA GRILLE 
		 * @param i : COORDONNEE EN X
		 * @param j : COORDONNEE EN Y
		 * @return
		 */
		public Case getCase(int i, int j) {
			return this.grille[i][j];
		}
		
		/**
		 * METHODE PERMETTANT D'ACCEDER AUX CORDONNEES A LA VALEUR CASE
		 * @param i : COORDONNEE EN X
		 * @param j : COORDONNEE EN Y
		 * @return
		 */
		public int getValue(int i, int j) {
			return this.grid[i][j];
		}
		
		
		/**
		 * METHODE PERMETANT DE PLACER DANS LES ELEMENTS DE LA GRILLE (LES CHIFFRES)
		 */
		public void placerElement() {
			for (int i = 0; i < dimension; i++) {
				for (int j = 0; j < dimension; j++) {
					Case casevide = new Case();
					
					// POUR METTRER 0 A DANS LA DERNIERE CASE
					if (i == dimension - 1 && j == dimension - 1)
						casevide.setValeur(0);
					grille[i][j] = casevide;
					
				}
			}
			// REMETRE LE COMPTEUR A 0 POUR UNE NOUVELLE PARTIE
			Case.cpt = 0; 
		}
		
		/**
		 * METHODE PERMETTANT D'INITIALISER UNE NOUVELLE GRILLE POUR FAIRE LA COMPARAISON AFIN DE DETERMINER LA FIN DU JEU 
		 */
		public Case[][] createGridCase() {
			Case[][] c = new Case[this.dimension][this.dimension];
		
			for (int i = 0; i < dimension; i++) {
				for (int j = 0; j < dimension; j++) {
					Case maCase = new Case();
					maCase.setCpt(1 + j + i * this.dimension);
					
					if (i == dimension - 1 && j == dimension - 1)
						maCase.setValeur(0);
					c[i][j] = maCase;
					c[0][0].setValeur(1);;
				}
			}
			return c;
		}
		

		/**
		 * METHODE DE REPERER LA POSITION DE 0 DANS LA GRILLE
		 * @return
		 */
		public CaseVide caseVide() {
			for (int i = 0; i < dimension; i++) {
				for (int j = 0; j < dimension; j++) {
					if (grille[i][j].getValeur() == 0) {
						return new CaseVide(i, j);
					}
				}
			}
			return null;
		}
		
		/**
		 * METHODE PERMETTANT D'AFFICHER LA GRILLE DANS LA CONSOLE
		 */
		public void affiche() {
			for (int i = 0; i < this.dimension; i++) {
				for (int j = 0; j < this.dimension; j++) {
					System.out.print(" | " + this.grille[i][j]);
				}
				System.out.println(" | ");
			}
			System.out.println();
		}

		/**
		 * 
		 * @return PERMUTATION A DROITE
		 */
		public boolean Permutation_Droite() {
			Case c;
			int i = caseVide().getI();
			int j = caseVide().getJ();

			if (j < dimension - 1) {
				c = grille[i][j];
				grille[i][j] = grille[i][j + 1];
				grille[i][j + 1] = c;
				fireChange();
				return true;
			}
			return false;
		}
		
		/**
		 * 
		 * @return PERMUTATION A GAUCHE
		 */
		public boolean Permutation_Gauche() {
			Case macase;
			int i = caseVide().getI();
			int j = caseVide().getJ();

			if (j > 0) {
				macase = grille[i][j];
				grille[i][j] = grille[i][j - 1];
				grille[i][j - 1] = macase;
				fireChange();
				return true;
			}
			return false;
		}
		
		/**
		 * 
		 * @return PERMUTATION HAUTE
		 */
		public boolean Permutation_Haute() {
			Case macase;
			int i = caseVide().getI();
			int j = caseVide().getJ();

			if (i > 0) {
				macase = grille[i][j];
				grille[i][j] = grille[i - 1][j];
				grille[i - 1][j] = macase;
				fireChange();
				return true;
			}
			return false;
		}
		/**
		 * 
		 * @return PERMUTATION BASSE
		 */
		public boolean Permutation_Basse() {
			Case macase;
			int i = caseVide().getI();
			int j = caseVide().getJ();
			;

			if (i < dimension - 1) {
				macase = grille[i][j];
				grille[i][j] = grille[i + 1][j];
				grille[i + 1][j] = macase;
				fireChange();
				return true;
			}
			return false;
		}
		
		/**
		 * LA LISTE DES DEPLACEMENTS POSSIBLES 
		 * @return la liste des permutations pouvant être éffectuées
		 */
		public ArrayList<Taquin> Permutations() {

			ArrayList<Taquin> listePermutation = new ArrayList<Taquin>();

			if (Permutation_Haute()) {
				listePermutation.add(this);
				this.Permutation_Basse();
			}
			if (Permutation_Basse()) {
				listePermutation.add(this);
				this.Permutation_Haute();
			}
			if (Permutation_Gauche()) {
				listePermutation.add(this);
				this.Permutation_Droite();
			}
			if (Permutation_Droite()) {
				listePermutation.add(this);
				this.Permutation_Gauche();
			}

			return listePermutation;
		}
		
		/**
		 * METHODE PERMETTANT D'UTILISER LA DIMENSION ET PALCER LES CASES POUR LA PARTIE GRAPHIQUE
		 * @param dimension
		 */
		public void initGrille(int dimension) {
			this.dimension = dimension;
			this.grille = new Case[dimension][dimension];
			this.placerElement();
		}
		
		public void setDimension(int dimension) {
			this.dimension = dimension;
			this.fireChange();
		}

		/**
		 * METHODE PERMETTANT DE MELANGER LES CHIFFRES DANS LA GRILLE ALEATOIREMENT
		 */
		public void Shuffle() {
			int n = 50;
			while (n!=0) {
				int random = (int)(4* Math.random());
				switch (random) {
				case 0:
					Permutation_Haute();
					break;
				case 1:
					Permutation_Basse();
					break;
				case 2:
					Permutation_Droite();
					break;
				case 3:
					Permutation_Gauche();
					break;
				}
				n--;
			}
		}
		
		/**
		 * METHODE PERMETTANT DE DETERMINER LA FIN SI TOUS LES CHIFFRES SONT DANS L'ORDRE
		 */
		
		public boolean isFinished() {
			for(int i = 0; i<this.dimension; i++) {
				for(int j = 0; j<this.dimension; j++) {
					if (!(this.grille[i][j].getValeur() == this.createGridCase()[i][j].getValeur())) {
						return false;
					}
				}
			}
			return true; 
		}

		/**
		 * LES SETTERS ET LES GETTERS
		 * @return
		 */
		public Case[][] getGrille() {
			return grille;
		}

		public void setGrille(Case[][] grille) {
			this.grille = grille;
		}

		public int getDimension() {
			return this.dimension;
		}
		public int getCompteur() {
			return compteur;
		}

		public void setCompteur(int compteur) {
			this.compteur = compteur;
		}

		public int[][] getGrid() {
			return grid;
		}

		public void setGrid(int[][] grid) {
			this.grid = grid;
		}



}
