package src;

public class Case {
	
	private int valeur;
	public static int cpt = 0;

	public Case() {
		cpt++;
		this.valeur =  (cpt);
	}
	

	public int getValeur() {
		return valeur;
	}

	public static int getCpt() {
		return cpt;
	}


	public void setValeur(int valeur) {
		this.valeur = valeur;
	}


	public void setCpt(int cpt) {
		this.cpt = cpt;
	}


	public String toString() {
		return String.valueOf(this.valeur);
	}

}

