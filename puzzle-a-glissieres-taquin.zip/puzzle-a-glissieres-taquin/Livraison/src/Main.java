package src;

import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/**
		 * INSTANCIATION DE LA CLASSE TAQUIN
		 */
		Taquin taquin  = new Taquin(3); 
		System.out.println("GRILLE INITIALE : ");
		taquin.Shuffle(); 
		taquin.affiche();

		 Vue vue=new Vue(3);
		
		/**
		 * POUR EFFECTUER LES DEPLACEMENT AVEC LE CLAVIER
		 */
		Scanner scanner = new Scanner(System.in);
		while(!taquin.isFinished()) {
			System.out.println("CHOISSISSEZ UN MOUVEMENT : d(roite); g(auche); h(aut) ; b(as)");
			String bouger = scanner.nextLine();
			
			switch (bouger) {
			case "h":
				taquin.Permutation_Haute();
				taquin.affiche();
				taquin.compteur++;
				break;
			case "b":
				taquin.Permutation_Basse();
				taquin.affiche();
				taquin.compteur++;
				break;
			case "d":
				taquin.Permutation_Droite();
				taquin.affiche();
				taquin.compteur++;
				break;
			case "g":
				taquin.Permutation_Gauche();
				taquin.affiche();
				taquin.compteur++;
				break;
			}
		}
		System.out.println(" LE JEU EST FINI");
		System.out.println(" LE NOMBRE DE PERMUTATION EFFECTUEE EST :" +taquin.getCompteur());
	}

}
