package src;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
public class Vue extends JFrame implements KeyListener, EcouteurModele {
	
	Taquin taquin;
	Fenetre fenetre;

	/**
	 * CONSTRUCTEUR
	 * @param dimension
	 */
	public Vue(int dimension) {
		this.addKeyListener(this);
		this.initialisation(dimension);
	}
	
	/**
	 * INITIALISATION DES PARAMETRES DE LA FENETRE
	 */
	private void initialisation(int dimension) {
		this.setTitle("JEU_TAQUIN");
		this.setSize(600, 660);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		/**
		 * INITIALISATION DE LA CLASSE TAQUIN ET FENETRE
		 * ET LE MELANGE DES CHIFFRES
		 */
		this.taquin = new Taquin(dimension);
		this.taquin.Shuffle();
		this.fenetre = new Fenetre(taquin, 600);
		this.getContentPane().add(fenetre);
	}

		/**
		 * METHODE PERMETTANT DE FAIRE LES PERMUTATIONS AVEC LES TOUCHES DE DIRECTIONS DU CLAVIER
		 */
		public void keyPressed(KeyEvent e) {
			
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			taquin.Permutation_Basse();
		} 
		else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			taquin.Permutation_Haute();
		} 
		else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			taquin.Permutation_Droite();
			
		} 
		else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			taquin.Permutation_Gauche();
			
		}
		this.repaint();
	}

	public void keyReleased(KeyEvent e) {
	}
	public void keyTyped(KeyEvent e) {
	}
	
	/**
	 * INITIALISATIONS DES PARAMETRES POUR UN JEU
	 * @param dimension
	 */
	public void inittaquin(int dimension) {
		initialisation(dimension);
		this.repaint();
	}
	
	/**
	 * METHODE PRENANT EN COMPTE LA MISE A JOUR DU MODELE
	 * @param source
	 */
	@Override
	public void modeleMisAJour(Object source) {
		
	}

}


