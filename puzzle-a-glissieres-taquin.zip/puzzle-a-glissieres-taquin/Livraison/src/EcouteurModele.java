package src;

public interface EcouteurModele {
	
	public void modeleMisAJour(Object source);	

}
