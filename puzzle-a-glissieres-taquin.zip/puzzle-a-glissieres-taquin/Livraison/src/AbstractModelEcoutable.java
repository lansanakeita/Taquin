package src;

import java.util.ArrayList;

public abstract class AbstractModelEcoutable {

protected ArrayList<EcouteurModele> listeEcouteurs = new ArrayList<EcouteurModele>();
	
	public void ajoutEcouteur(EcouteurModele ecouteur) {
		listeEcouteurs.add(ecouteur);
	}

	@SuppressWarnings("unlikely-arg-type")
	public void retraitEcouteur(EcouteurModele ecouteur) {
		listeEcouteurs.remove(ecouteur);
	}
	protected  void fireChange() {
		for (EcouteurModele ecouteurModele : listeEcouteurs) {
			ecouteurModele.modeleMisAJour(this);
		}
	}

}
