package src;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VictoireAlert extends JFrame implements EcouteurModele{
	
	private JPanel panel = new JPanel();
	private JPanel panel2 = new JPanel();
	public VictoireAlert() {
		
		Taquin taquin = new Taquin(3);
		Fenetre fenetre = new Fenetre(taquin, 600);
		this.setLayout(new GridLayout(3,1));
		
	//CREATION D'UN LABEL 
		
		panel.setBackground(Color.GRAY);
		JLabel label = new JLabel(" Felicitation la Partie Est Finie");
		Font font = new Font("Arial",Font.BOLD,25);
		label.setFont(font);

		//CREATION D'UN BUTTON
		
		panel2.setBackground(Color.GRAY);
		JButton bouton = new JButton(" NOUVELLE PARTIE ");
		JButton bouton2 = new JButton(" QUITTER ");

	

	
	// AJOUT DES COMPOSANTS
	panel.add(label);
	panel2.add(bouton);
	panel2.add(bouton2);
	add(panel); 
	add(panel2); 
	
	
	/**
	 * ASSOCIER UN EVENEMENT AU BUTTON POUR LANCER UNE NOUVELLE PARTIE
	 */
	bouton.addActionListener(new ActionListener()
  	{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			Vue v = new Vue(3);
		}
  	});
	
	/**
	 * POUR QUITTER LE JEU
	 */
	bouton2.addActionListener(new ActionListener()
  	{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			System.exit(0);
		}
  	});
	
	/**
	 * LES PRORPRIETES DE LA FENETRE
	 */
	this.setTitle("ALERT MESSAGE");
	this.setSize(450, 250);
	this.setLocationRelativeTo(null); 
	this.setResizable(false); 
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.setVisible(true);
	}

	@Override
	public void modeleMisAJour(Object source) {
		// TODO Auto-generated method stub
		
		
	}

}
