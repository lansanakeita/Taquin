package src;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fenetre extends JPanel implements MouseListener, MouseMotionListener, EcouteurModele {

		/**
		 * LES ATTRIBUTS DE LA CLASSE
		 * DIMENSION: REPRESENTE LE NOMBRE DE CASE
		 * LARGEUR  : REPRESENTE LA SURFACE SUR LA QUELLE LES CASES SERONT REPRESENTEES
		 * SIZE		: REPRESENTE LA TAILLE D'UNE CASE
		 * PADDING 	: REPRESENTE LES BORDURES POUR LA SURFACE DE JEUX
		 */
		private Taquin taquin;
		private int dimension; 
		private int largeur; 
		private int size; 
		private final int padding = 5; 
		
		/**
		 * LE CONSTRUCTEUR
		 * @param taquin
		 * @param largeur
		 */
		public Fenetre(Taquin taquin, int largeur) {
			this.taquin = taquin;
			this.dimension = taquin.getDimension(); 
			this.largeur = largeur; 
			this.size = (largeur - (2 * padding)) / taquin.getDimension(); 
			this.setSize(largeur, largeur);
			this.addMouseListener(this);
			this.addMouseMotionListener(this);
			this.taquin.ajoutEcouteur(this); 
			
		}
		
		/**
		 * METHODE PERMETTANT DE : 
		 * PLACER LES CASES
		 * TRACER LES BORDURES 
		 * GERER LES COULEURS 
		 */
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			 // Taille , Couleur et  Style d'ecriture
			Font font = new Font("SansSerif", Font.BOLD, 50);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, this.largeur, this.largeur);
			
			// PLacers les cases sur la fenetre et les couleurs
			g.setColor(Color.RED);
			for (int i = 0; i < this.taquin.getDimension(); i++) {
				for (int j = 0; j < this.taquin.getDimension(); j++) {
					g.fillRoundRect(this.padding + (size * i), this.padding + (size * j), size, size, 50, 50);// Contour des Case
				}
			}
			// Mise en forme des Cases
			g.setColor(Color.BLACK);
			for (int i = 0; i < this.taquin.getDimension(); i++) {
				for (int j = 0; j < this.taquin.getDimension(); j++) {
					g.drawRoundRect(this.padding + (size * i), this.padding + (size * j), size, size, 55, 50);
				}	
			}
			
			// Placer des Chifres dans les Cases 
			g.setColor(Color.BLACK);
			g.setFont(font);
			for (int i = 0; i < this.taquin.getDimension(); i++) {
				for (int j = 0; j < this.taquin.getDimension(); j++) {
					
					// SI LA DERNIERE CASE EST VIDE
					if (this.taquin.getCase(i, j).getValeur() == 0) {
						g.fillRoundRect(this.padding + (size * j), this.padding + (size * i), size, size, 15, 15);
					}
					else {
						// SI LA DERNIERE CASE N'EST PAS VIDE
						g.drawString(this.taquin.getCase(i, j).toString(),((size / 2) + (size * j)) - padding,
								((size / 2) + (font.getSize() / 2) + (size * i))- padding);
					}
				}	
			}
			if(taquin.isFinished()) {

				new VictoireAlert(); 
			}
		}
		
		/**
		 * METHODE PERMETTANT DE FAIRE LES PERMUTATIONS AVEC LA SOURIS 
		 */
		public void mousePressed(MouseEvent e) {

			int i = (e.getY()) / size;
			int j = (e.getX()) / size;

			if (taquin.Permutation_Droite() && !(taquin.caseVide().getI() == i && taquin.caseVide().getJ() == j)) {
				taquin.Permutation_Gauche();
				
			}
			if (taquin.Permutation_Gauche() && !(taquin.caseVide().getI() == i && taquin.caseVide().getJ() == j)) {
				taquin.Permutation_Droite();
				
			}
			if (taquin.Permutation_Haute() && !(taquin.caseVide().getI() == i && taquin.caseVide().getJ() == j)) {
				taquin.Permutation_Basse();
				
			}
			if (taquin.Permutation_Basse() && !(taquin.caseVide().getI() == i && taquin.caseVide().getJ() == j)) {
				taquin.Permutation_Haute();
				
			}
			modeleMisAJour(this);	
			this.repaint();

		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
			
		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseClicked(MouseEvent e) {
		}

		@Override
		public void mouseDragged(MouseEvent arg0) {
			// TODO Auto-generated method stub	
		}

		@Override
		public void mouseMoved(MouseEvent arg0) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void modeleMisAJour(Object source) {
			repaint();
		}

	}

